# LunchTrayApp
Project to learn Jetpack Navigation, DataBinding and ViewModel


## YouTube Video Tutorial
https://youtu.be/6TVX2EHiuGI
