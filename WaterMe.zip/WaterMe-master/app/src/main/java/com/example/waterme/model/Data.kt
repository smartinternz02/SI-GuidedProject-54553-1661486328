package com.example.waterme.model

data class PlantData(

    val imageResources : Int,
    val plantTitle : String,
    val plantDescription : String,
    val plantReminder : String
)