# WaterMe
The projects is currently being worked on with commits made on a regularly basis. The idea of this project
is to familiarize myself with use of WorkManager for background tasks, and Notification Channel
